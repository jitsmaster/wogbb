<!--
*************************************
Template designed by Austin Gregory of
AwfulMedia.com. Before using or modifying this file
please read the included license
*************************************
Date: 6/7/2012
Author: Austin Gregory
Website: AwfulMedia.com
*************************************
-->
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <title>Free Bootstrap Template - Respond</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="">
    <meta name="author" content="">

    <!-- Le styles -->
    <link href="css/bootstrap.css" rel="stylesheet">
    <style type="text/css">

    </style>
    <link href="css/bootstrap-responsive.css" rel="stylesheet">
    <!-- Le HTML5 shim, for IE6-8 support of HTML5 elements -->
    <!--[if lt IE 9]>
      <script src="http://html5shim.googlecode.com/svn/trunk/html5.js"></script>
    <![endif]-->

    <!-- Le fav and touch icons -->
    <link rel="shortcut icon" href="ico/favicon.ico">
    <link rel="apple-touch-icon-precomposed" sizes="144x144" href="ico/apple-touch-icon-144-precomposed.png">
    <link rel="apple-touch-icon-precomposed" sizes="114x114" href="ico/apple-touch-icon-114-precomposed.png">
    <link rel="apple-touch-icon-precomposed" sizes="72x72" href="ico/apple-touch-icon-72-precomposed.png">
    <link rel="apple-touch-icon-precomposed" href="ico/apple-touch-icon-57-precomposed.png">
	<link href='http://fonts.googleapis.com/css?family=Lato:300' rel='stylesheet' type='text/css'>
  </head>

  <body>

    <div class="navbar navbar-fixed-top">
      <div class="navbar-inner">
        <div class="container">
          <a class="btn btn-navbar" data-toggle="collapse" data-target=".nav-collapse">
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
          </a>
          <a class="brand" href="index.php"><span class="color-highlight">R</span>espond 1.5</a>
          <div class="nav-collapse">
            <ul class="nav pull-right">
              <li><a href="index.php">Home</a></li>
              <li class="active"><a href="services.php">Services</a></li>
              <li><a href="portfolio.php">Portfolio</a></li>
			  <li><a href="contact.php">Contact</a></li>
			  <li><a href="about.php">About</a></li>
            </ul>
          </div><!--/.nav-collapse -->
        </div>
      </div>
    </div>
	<div class="container">
	<hr>
      <div class="row">
        <div class="span8">
			
			<div class="well">
			<h1>Services</h1>
					<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Donec a lorem nec dolor 
					suscipit posuere in id erat. Quisque accumsan pharetra commodo. Morbi sit amet lectus leo, 
					faucibus facilisis felis. Aenean hendrerit nibh non leo elementum nec tristique nisl dictum. 
					Suspendisse id felis massa, ac dapibus eros. Cum sociis natoque penatibus et magnis dis 
					parturient montes, nascetur ridiculus mus. Aliquam erat volutpat. Pellentesque mollis varius 
					nisl. Sed non velit tincidunt eros pulvinar molestie facilisis et est. Donec sem elit, eleifend 
					quis sagittis non, porttitor nec orci. Aenean ut nisl est, sed tincidunt justo. Quisque elementum
					pharetra metus, in ornare nisi accumsan placerat. Integer volutpat lectus sed urna pretium 
					tincidunt. Sed dui libero, congue nec eleifend tristique, pharetra eget odio. Aenean at est 
					velit, sed posuere ligula. Nulla condimentum elit ac mauris rutrum tempor.</p>
					<ul>
						<li>Sed non velit tincidunt eros pulvinar</li>
						<li>Nulla condimentum elit</li>
						<li>Sed non velit tincidunt eros pulvinar</li>
						<li>Nulla condimentum elit</li>
					</ul>
					<p>In interdum rhoncus pharetra. Vivamus diam sem, commodo faucibus vestibulum dictum, suscipit id 
					nulla. Sed est tortor, imperdiet vel pellentesque in, egestas at diam. Donec auctor suscipit dignissim. 
					Donec enim quam, accumsan a feugiat ac, adipiscing nec ipsum. Pellentesque habitant morbi tristique 
					senectus et netus et malesuada fames ac turpis egestas. Nullam placerat consequat nibh. Nulla erat justo, 
					pharetra eu dignissim at, sollicitudin eu arcu.</p>
					<ol>
						<li>Sed non velit tincidunt eros pulvinar</li>
						<li>Nulla condimentum elit</li>
						<li>Sed non velit tincidunt eros pulvinar</li>
						<li>Nulla condimentum elit</li>
					</ol>
					<p>Phasellus suscipit purus in enim pharetra id viverra ante porta. Vestibulum faucibus dictum eleifend. 
					Pellentesque enim orci, tristique id ultrices at, posuere eu diam. Aliquam vel pharetra justo. Ut rutrum 
					pellentesque dolor quis fringilla. Donec tempor eleifend nisi quis ullamcorper. Nullam quis massa ante, 
					at ullamcorper mi. Proin dictum mi fermentum risus sodales posuere. Fusce sollicitudin sagittis pulvinar. 
					Proin eu ipsum ac neque aliquet posuere. Maecenas a mauris nisi.</p>

			</div>
        </div>
		<div class="span4">
			<p><h3>Deep Sky<small> By <a href="http://commons.wikimedia.org/wiki/File:Nature_1.jpg">Srawat56</a><small><h3></p>
			<a href=#"><img src="img/thumb1.jpg" alt="Thumbnail"></a>
			<p><h3>Deep Sky<small> By <a href="http://commons.wikimedia.org/wiki/File:Nature_1.jpg">Srawat56</a><small><h3></p>
			<a href=#"><img src="img/thumb1.jpg" alt="Thumbnail"></a>
        </div>
      </div>
	  <!--Start second row of columns-->
	  <div class="row">
		<div class="span4">
			<p><h3>Column One</h3></span></p>
			<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed placerat sem vel nibh bibendum auctor. 
			Nullam non magna in quam egestas blandit a a justo. Integer vel rhoncus tellus. 
			Vivamus et iaculis tortor. Quisque fermentum arcu dolor. Duis mollis libero et 
			ipsum euismod sed gravida sem pretium. Aliquam eu eros at velit laoreet rhoncus. 
			Nulla a urna eu diam cursus tempor.</p>
		</div>
		<div class="span4">
			<p><h3>Column Two</h3></span></p>
			<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed placerat sem vel nibh bibendum auctor. 
			Nullam non magna in quam egestas blandit a a justo. Integer vel rhoncus tellus. 
			Vivamus et iaculis tortor. Quisque fermentum arcu dolor. Duis mollis libero et 
			ipsum euismod sed gravida sem pretium. Aliquam eu eros at velit laoreet rhoncus. 
			Nulla a urna eu diam cursus tempor.</p>
		</div>
		<div class="span4">
			<p><h3>Column Three</h3></span></p>
			<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed placerat sem vel nibh bibendum auctor. 
			Nullam non magna in quam egestas blandit a a justo. Integer vel rhoncus tellus. 
			Vivamus et iaculis tortor. Quisque fermentum arcu dolor. Duis mollis libero et 
			ipsum euismod sed gravida sem pretium. Aliquam eu eros at velit laoreet rhoncus. 
			Nulla a urna eu diam cursus tempor.</p>
		</div>
	  </div>

      <hr>

				<footer class="row">
			<div>
				<div class="span4">
					<div class="is-padded">
						<nav>
							<h2>Navigation</h2>
							<hr>
							<ul>
								<li><a href="#">Home</a></li>
								<li><a href="#">Services</a></li>
								<li><a href="#">Portfolio</a></li>
								<li><a href="#">Contact</a></li>
								<li><a href="#">About</a></li>
							</ul>
						</nav>
					</div>
				</div>
				<div class="span4">
					<div class="is-padded">
						<h2>Twitter</h2>
						<hr>
						<a href="#">@AwfulMedia</a>
						<p>This is what my tweet looks like on this website. Tweet tweet. Twitter Twatter.</p>
						<em>3 days ago</em><br>
						<br>
						<a href="#">@AwfulMedia</a>
						<p>This is what my tweet looks like on this website. Tweet tweet. Twitter Twatter.</p>
						<em>3 days ago</em>
					</div>
				</div>
				<div class="span4">
					<div class="is-padded">
				  <h2>Details</h2>
						  <blockquote>Respond is a fully responsive website template utilizing Twitter's Bootstrap framework. 
						  What does that mean? First of all, the website will respond according to the size of the 
						  viewers browser window. Go on, try it out. Resize your window. On top of that, the framework 
						  offers loads of ready-to-go features. Check it out with the button below.
						  <br><br>
						  <em>- AwfulMedia.com</em>
						  </blockquote>
					  </div>
				</div>
			</div>
			<p>
			&copy;2012 Your Company.<br>
			Design by <a href="http:/www.awfulmedia.com">AwfulMedia.com</a>
			</p>
		</footer>

    </div><!-- /container -->

    <!-- Le javascript
    ================================================== -->
    <!-- Placed at the end of the document so the pages load faster -->
    <script src="js/jquery.js"></script>
    <script src="js/bootstrap-transition.js"></script>
	<script src="js/bootstrap-carousel.js"></script>
    <script src="js/bootstrap-alert.js"></script>
    <script src="js/bootstrap-modal.js"></script>
    <script src="js/bootstrap-dropdown.js"></script>
    <script src="js/bootstrap-scrollspy.js"></script>
    <script src="js/bootstrap-tab.js"></script>
    <script src="js/bootstrap-tooltip.js"></script>
    <script src="js/bootstrap-popover.js"></script>
    <script src="js/bootstrap-button.js"></script>
    <script src="js/bootstrap-collapse.js"></script>
    <script src="js/bootstrap-typeahead.js"></script>
	<script src="js/jquery-ui-1.8.18.custom.min.js"></script>
	<script src="js/jquery.smooth-scroll.min.js"></script>
	<script src="js/lightbox.js"></script>
  </body>
</html>
